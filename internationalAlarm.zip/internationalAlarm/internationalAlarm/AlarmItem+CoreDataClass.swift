//
//  AlarmItem+CoreDataClass.swift
//  internationalAlarm
//
//  Created by essdessder on 5/13/20.
//  Copyright © 2020 essdessder. All rights reserved.
//
//
// Created by Yusen Chen. essdessder is my mac name/ online handle

import Foundation
import CoreData

@objc(AlarmItem)
public class AlarmItem: NSManagedObject {

}
